# Code of Conduct

This project follows a pragmatic professional standard: be precise, cite sources, preserve attribution, avoid harassment, and do not use the project to misrepresent certification status.
