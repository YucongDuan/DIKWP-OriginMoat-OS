import json
from pathlib import Path

from dikwp_originmoat.evaluator import evaluate, load_manifest
from dikwp_originmoat.static_audit import audit_path


def test_evaluate_sample():
    raw = json.loads(Path("examples/sample_ecosystem.json").read_text(encoding="utf-8"))
    manifest = load_manifest(raw)
    report = evaluate(manifest)
    assert report.portfolio_score > 0.7
    assert report.copycat_pressure > 0.6
    assert len(report.layer_decisions) == len(manifest.projects)


def test_registry_assets_controlled():
    raw = json.loads(Path("examples/sample_ecosystem.json").read_text(encoding="utf-8"))
    report = evaluate(load_manifest(raw))
    trust = [x for x in report.layer_decisions if "TrustPassport" in x.asset_name][0]
    assert trust.release_layer == "open_verifier_private_issuer"


def test_static_audit_passes():
    result = audit_path(Path("src"))
    assert result["pass"] is True
