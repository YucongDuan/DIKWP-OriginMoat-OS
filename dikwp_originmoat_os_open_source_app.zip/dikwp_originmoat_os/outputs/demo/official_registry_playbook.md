# Official Registry Playbook

The public registry should be controlled by the origin holder or authorized DIKWP organization. The open-source tool may generate candidate entries, but official status requires manual review.

Minimum registry fields:
- Project ID
- Origin holder
- Repository URL
- Release version
- Origin capsule hash
- NOTICE/CITATION status
- TrustPassport score
- Certification scope
- Expiry date
- Revocation status

Open verifier, private issuer: publish validation schemas and badge display rules, but keep signing keys and final certification decisions controlled.
