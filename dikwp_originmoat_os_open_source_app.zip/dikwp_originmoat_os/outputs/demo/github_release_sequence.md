# GitHub Release Sequence

1. Publish DIKWP TrustPassport OS first.
2. Publish OriginMoat OS as the strategy and release-planning layer.
3. Publish high-adoption, low-risk tools as traffic generators.
4. Publish conformance tests and schemas for strategic protocols.
5. Keep official issuer keys, certification decisions and premium adapter packs controlled.
6. Build a public registry page that recognizes projects preserving DIKWP attribution.
7. Convert serious users into training, support, certification and integration partners.
