# DIKWP Partner Program Blueprint

## Tiers
- Community Implementer: preserves attribution and passes basic TrustPassport checks.
- Registered Partner: publishes registry entry, citation pack and project boundary statement.
- Certified Integrator: passes official conformance tests and can deliver enterprise deployments.
- Strategic Industry Partner: co-develops sector adapter packs under written agreement.

## Revenue routes
- Certification review fees
- Enterprise support
- Training and certification
- Sector adapter packs
- Registry listing and procurement reports
- Joint pilots

## Non-negotiable boundaries
No false official claims, no removal of DIKWP attribution, no unsafe deployment claims, no use of certification badge without registry entry.
