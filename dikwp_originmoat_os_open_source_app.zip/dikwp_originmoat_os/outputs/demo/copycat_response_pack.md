# Copycat Response Pack

## Purpose
Convert ambiguous or adversarial reuse into attribution, citation, partner registration, or formal review.

## First response
1. Record the derivative project URL, release date, copied terms, copied files, and missing attribution.
2. Compare against the official origin capsule and public registry entry.
3. Send a non-hostile attribution correction request first.
4. Offer partner registration if the derivative is useful and non-deceptive.
5. Escalate to legal review only if the derivative falsely claims official status, removes attribution, misuses trademark, or harms users.

## Message template
We noticed your project uses DIKWP concepts or code derived from the DIKWP ecosystem. Please preserve NOTICE and CITATION metadata and avoid claiming official DIKWP certification unless your project has an official registry entry. We welcome partner registration and can provide a public TrustPassport route.
