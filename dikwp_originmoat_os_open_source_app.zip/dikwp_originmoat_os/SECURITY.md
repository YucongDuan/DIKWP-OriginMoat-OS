# Security Policy

The offline core should not perform network access, hidden telemetry, host mutation, subprocess execution, credential handling, or legal enforcement automation.

Report suspected vulnerabilities by opening a GitHub issue without posting sensitive material.
