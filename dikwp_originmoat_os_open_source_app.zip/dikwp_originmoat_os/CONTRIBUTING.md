# Contributing

Contributions are welcome if they preserve DIKWP attribution, evidence-ledger discipline, safety boundaries, and the distinction between open code and official certification authority.

Do not submit code that adds hidden telemetry, network scraping, legal enforcement automation, host mutation, or covert attribution manipulation.
