from __future__ import annotations

from dataclasses import asdict
from statistics import mean
from typing import Dict, List

from .models import EcosystemManifest, LayerDecision, ProjectAsset, StrategyReport


def clamp(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def normalize_asset(raw: Dict) -> ProjectAsset:
    return ProjectAsset(
        name=str(raw.get("name", "unnamed_asset")),
        category=str(raw.get("category", "unknown")),
        description=str(raw.get("description", "")),
        public_value=clamp(raw.get("public_value", 0.5)),
        copycat_risk=clamp(raw.get("copycat_risk", 0.5)),
        attribution_strength=clamp(raw.get("attribution_strength", 0.5)),
        official_dependency=clamp(raw.get("official_dependency", 0.5)),
        commercial_potential=clamp(raw.get("commercial_potential", 0.5)),
        contains_core_protocol=bool(raw.get("contains_core_protocol", False)),
        contains_certification_logic=bool(raw.get("contains_certification_logic", False)),
        contains_registry_logic=bool(raw.get("contains_registry_logic", False)),
        recommended_license=str(raw.get("recommended_license", "Apache-2.0")),
        notes=list(raw.get("notes", [])),
    )


def load_manifest(raw: Dict) -> EcosystemManifest:
    projects = [normalize_asset(x) for x in raw.get("projects", [])]
    return EcosystemManifest(
        ecosystem_name=str(raw.get("ecosystem_name", "DIKWP Ecosystem")),
        origin_holder=str(raw.get("origin_holder", "Yucong Duan / DIKWP")),
        strategic_intent=str(raw.get("strategic_intent", "preserve origin, grow adoption, capture official value")),
        projects=projects,
    )


def decide_layer(asset: ProjectAsset) -> LayerDecision:
    danger = max(asset.copycat_risk, 0.8 if asset.contains_registry_logic else 0.0, 0.75 if asset.contains_certification_logic else 0.0)
    adoption = asset.public_value
    official = asset.official_dependency

    if asset.contains_registry_logic or asset.contains_certification_logic:
        return LayerDecision(
            asset_name=asset.name,
            release_layer="open_verifier_private_issuer",
            reason="Verifier, schema and examples can be open; issuer keys, official registry, certificate signing and final badge authority should remain controlled.",
            official_service_route="Official DIKWP registry, certification review, enterprise procurement report and partner listing.",
            copycat_countermeasure="Require public registry ID, signed badge, CITATION.cff and origin evidence bundle for valid claims.",
        )
    if danger >= 0.75 and official >= 0.55:
        return LayerDecision(
            asset_name=asset.name,
            release_layer="reference_core_open_premium_adapters_controlled",
            reason="The project is useful for adoption but easy to repackage; open the reference core while keeping industry templates, official tests and certification paths as controlled service assets.",
            official_service_route="Paid adapter packs, conformance tests, training certification and enterprise deployment support.",
            copycat_countermeasure="Add attribution checks, official badge routes, partner terms and release chronology evidence.",
        )
    if adoption >= 0.7 and asset.attribution_strength >= 0.6:
        return LayerDecision(
            asset_name=asset.name,
            release_layer="fully_open_adoption_driver",
            reason="High public adoption value and acceptable attribution strength; use it as ecosystem traffic and citation generator.",
            official_service_route="Community growth, training, support, templates and integration services.",
            copycat_countermeasure="Preserve NOTICE, CITATION.cff, release DOI and TrustPassport metadata.",
        )
    if asset.commercial_potential >= 0.75 and danger >= 0.6:
        return LayerDecision(
            asset_name=asset.name,
            release_layer="spec_open_implementation_selective",
            reason="Commercial potential and copycat risk are both high; publish specs, schemas and demo outputs, but keep production connectors and client-specific playbooks controlled.",
            official_service_route="Enterprise licensing, consulting, official roadmap and co-development agreements.",
            copycat_countermeasure="Use contributor license agreements, partner MOUs, public case registry and trademark-sensitive wording.",
        )
    return LayerDecision(
        asset_name=asset.name,
        release_layer="community_open_with_attribution_guard",
        reason="Moderate risk and value; open as community tool with attribution and origin metadata.",
        official_service_route="Optional support and roadmap sponsorship.",
        copycat_countermeasure="Require NOTICE, CITATION.cff and origin capsule in derived distributions.",
    )


def evaluate(manifest: EcosystemManifest) -> StrategyReport:
    if not manifest.projects:
        return StrategyReport(
            ecosystem_name=manifest.ecosystem_name,
            origin_holder=manifest.origin_holder,
            portfolio_score=0.0,
            copycat_pressure=0.0,
            attribution_integrity=0.0,
            commercial_route_strength=0.0,
            recommended_strategy="insufficient_project_manifest",
            layer_decisions=[],
            kill_conditions=["No projects supplied."],
            recovery_actions=["Add project manifests with public value, copycat risk, official dependency and attribution strength."],
        )

    portfolio_score = mean([0.35 * p.public_value + 0.25 * p.commercial_potential + 0.25 * p.official_dependency + 0.15 * p.attribution_strength for p in manifest.projects])
    copycat_pressure = mean([p.copycat_risk for p in manifest.projects])
    attribution_integrity = mean([p.attribution_strength for p in manifest.projects])
    commercial_route_strength = mean([0.45 * p.commercial_potential + 0.35 * p.official_dependency + 0.20 * p.public_value for p in manifest.projects])
    layer_decisions = [decide_layer(p) for p in manifest.projects]

    if copycat_pressure > 0.7 and attribution_integrity < 0.65:
        recommended_strategy = "origin_first_open_core: publish reference tools only after TrustPassport, CITATION, registry and partner route are in place"
    elif commercial_route_strength > 0.72:
        recommended_strategy = "certification_led_open_source: open schemas and tests, monetize official certification, adapters and deployment support"
    elif portfolio_score > 0.70:
        recommended_strategy = "adoption_led_ecosystem: maximize open adoption while enforcing attribution and registry metadata"
    else:
        recommended_strategy = "selective_release: strengthen attribution, documentation and demo proof before wide release"

    kill_conditions = [
        "A derivative removes DIKWP/Yucong Duan attribution and markets itself as original.",
        "A project claims official DIKWP certification without registry entry or signed badge.",
        "Core registry or issuer keys are accidentally open-sourced.",
        "Open-source license choice conflicts with commercial service route.",
        "Projects publish high-risk industry control logic without governance boundary.",
    ]
    recovery_actions = [
        "Issue updated NOTICE/CITATION guidance and public registry clarification.",
        "Move official issuer and certification authority into controlled registry service.",
        "Create public comparison page listing official vs unregistered derivatives.",
        "Offer partner conversion path before adversarial escalation.",
        "Use legal counsel for trademark, copyright or contract enforcement if needed.",
    ]

    return StrategyReport(
        ecosystem_name=manifest.ecosystem_name,
        origin_holder=manifest.origin_holder,
        portfolio_score=round(portfolio_score, 4),
        copycat_pressure=round(copycat_pressure, 4),
        attribution_integrity=round(attribution_integrity, 4),
        commercial_route_strength=round(commercial_route_strength, 4),
        recommended_strategy=recommended_strategy,
        layer_decisions=layer_decisions,
        kill_conditions=kill_conditions,
        recovery_actions=recovery_actions,
    )
