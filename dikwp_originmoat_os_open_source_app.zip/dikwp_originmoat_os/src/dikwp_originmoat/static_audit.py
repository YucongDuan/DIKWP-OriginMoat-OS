from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "requests", "urllib", "httpx", "subprocess", "paramiko", "ftplib", "telnetlib"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}
FORBIDDEN_ATTR_CALLS = {"system", "popen", "spawn", "remove", "unlink", "rmdir"}


def audit_path(src_dir: Path) -> Dict:
    findings: List[Dict] = []
    for path in src_dir.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    if root in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "value": alias.name})
            elif isinstance(node, ast.ImportFrom):
                root = (node.module or "").split(".")[0]
                if root in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(path), "type": "forbidden_import", "value": node.module})
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
                    findings.append({"file": str(path), "type": "forbidden_call", "value": node.func.id})
                if isinstance(node.func, ast.Attribute) and node.func.attr in FORBIDDEN_ATTR_CALLS:
                    findings.append({"file": str(path), "type": "sensitive_attr_call", "value": node.func.attr})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, or host mutation helpers in the offline strategy core."
    }


def write_audit(src_dir: Path, out: Path) -> Dict:
    result = audit_path(src_dir)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
