from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Dict, List

from .models import EcosystemManifest, StrategyReport


def write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def short_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def render_markdown_summary(report: StrategyReport) -> str:
    lines = []
    lines.append("# DIKWP OriginMoat Strategy Summary")
    lines.append("")
    lines.append(f"Ecosystem: **{report.ecosystem_name}**")
    lines.append(f"Origin holder: **{report.origin_holder}**")
    lines.append(f"Portfolio score: **{report.portfolio_score}**")
    lines.append(f"Copycat pressure: **{report.copycat_pressure}**")
    lines.append(f"Attribution integrity: **{report.attribution_integrity}**")
    lines.append(f"Commercial route strength: **{report.commercial_route_strength}**")
    lines.append("")
    lines.append("## Recommended strategy")
    lines.append(report.recommended_strategy)
    lines.append("")
    lines.append("## Layer decisions")
    for d in report.layer_decisions:
        lines.append(f"- **{d.asset_name}** -> `{d.release_layer}`: {d.reason}")
    lines.append("")
    lines.append("## Kill conditions")
    for k in report.kill_conditions:
        lines.append(f"- {k}")
    lines.append("")
    lines.append("## Recovery actions")
    for r in report.recovery_actions:
        lines.append(f"- {r}")
    return "\n".join(lines)


def generate_outputs(manifest: EcosystemManifest, report: StrategyReport, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    report_dict = report.to_dict()
    write_json(out_dir / "originmoat_strategy_report.json", report_dict)
    (out_dir / "originmoat_strategy_summary.md").write_text(render_markdown_summary(report), encoding="utf-8")

    layer_rows = []
    for d in report.layer_decisions:
        layer_rows.append({
            "asset_name": d.asset_name,
            "release_layer": d.release_layer,
            "reason": d.reason,
            "official_service_route": d.official_service_route,
            "copycat_countermeasure": d.copycat_countermeasure,
        })
    write_csv(out_dir / "open_core_release_map.csv", layer_rows)

    license_rows = []
    for p in manifest.projects:
        license_rows.append({
            "asset_name": p.name,
            "recommended_license": p.recommended_license,
            "notice_required": "yes",
            "citation_required": "yes",
            "trustpassport_required_for_official_claims": "yes",
            "commercial_service_route": "support/certification/adapters/training" if p.commercial_potential >= 0.5 else "community support",
        })
    write_csv(out_dir / "license_and_attribution_matrix.csv", license_rows)

    controlled = []
    for p in manifest.projects:
        if p.contains_registry_logic or p.contains_certification_logic or p.copycat_risk >= 0.75:
            controlled.append({
                "asset_name": p.name,
                "controlled_elements": [
                    "official registry entry",
                    "issuer private key",
                    "certification decision authority",
                    "enterprise adapter playbooks",
                    "partner commercial terms",
                ],
                "open_elements": [
                    "schema",
                    "offline verifier",
                    "demo data",
                    "documentation",
                    "community tests",
                ],
            })
    write_json(out_dir / "controlled_asset_registry_template.json", controlled)

    registry_entries = []
    for p in manifest.projects:
        registry_entries.append({
            "project_id": f"DIKWP-{short_hash(p.name)}",
            "project_name": p.name,
            "origin_holder": manifest.origin_holder,
            "origin_capsule_hash": short_hash(p.name + p.description + manifest.origin_holder),
            "trustpassport_status": "candidate",
            "official_claims_allowed": ["origin attributed", "DIKWP-related", "registry candidate"],
            "official_claims_blocked_without_review": ["certified", "official standard", "government approved", "exclusive"],
        })
    write_json(out_dir / "public_registry_entries.json", registry_entries)

    copycat_md = """# Copycat Response Pack\n\n## Purpose\nConvert ambiguous or adversarial reuse into attribution, citation, partner registration, or formal review.\n\n## First response\n1. Record the derivative project URL, release date, copied terms, copied files, and missing attribution.\n2. Compare against the official origin capsule and public registry entry.\n3. Send a non-hostile attribution correction request first.\n4. Offer partner registration if the derivative is useful and non-deceptive.\n5. Escalate to legal review only if the derivative falsely claims official status, removes attribution, misuses trademark, or harms users.\n\n## Message template\nWe noticed your project uses DIKWP concepts or code derived from the DIKWP ecosystem. Please preserve NOTICE and CITATION metadata and avoid claiming official DIKWP certification unless your project has an official registry entry. We welcome partner registration and can provide a public TrustPassport route.\n"""
    (out_dir / "copycat_response_pack.md").write_text(copycat_md, encoding="utf-8")

    partner_md = """# DIKWP Partner Program Blueprint\n\n## Tiers\n- Community Implementer: preserves attribution and passes basic TrustPassport checks.\n- Registered Partner: publishes registry entry, citation pack and project boundary statement.\n- Certified Integrator: passes official conformance tests and can deliver enterprise deployments.\n- Strategic Industry Partner: co-develops sector adapter packs under written agreement.\n\n## Revenue routes\n- Certification review fees\n- Enterprise support\n- Training and certification\n- Sector adapter packs\n- Registry listing and procurement reports\n- Joint pilots\n\n## Non-negotiable boundaries\nNo false official claims, no removal of DIKWP attribution, no unsafe deployment claims, no use of certification badge without registry entry.\n"""
    (out_dir / "partner_program_blueprint.md").write_text(partner_md, encoding="utf-8")

    release_md = """# GitHub Release Sequence\n\n1. Publish DIKWP TrustPassport OS first.\n2. Publish OriginMoat OS as the strategy and release-planning layer.\n3. Publish high-adoption, low-risk tools as traffic generators.\n4. Publish conformance tests and schemas for strategic protocols.\n5. Keep official issuer keys, certification decisions and premium adapter packs controlled.\n6. Build a public registry page that recognizes projects preserving DIKWP attribution.\n7. Convert serious users into training, support, certification and integration partners.\n"""
    (out_dir / "github_release_sequence.md").write_text(release_md, encoding="utf-8")

    official_registry_md = """# Official Registry Playbook\n\nThe public registry should be controlled by the origin holder or authorized DIKWP organization. The open-source tool may generate candidate entries, but official status requires manual review.\n\nMinimum registry fields:\n- Project ID\n- Origin holder\n- Repository URL\n- Release version\n- Origin capsule hash\n- NOTICE/CITATION status\n- TrustPassport score\n- Certification scope\n- Expiry date\n- Revocation status\n\nOpen verifier, private issuer: publish validation schemas and badge display rules, but keep signing keys and final certification decisions controlled.\n"""
    (out_dir / "official_registry_playbook.md").write_text(official_registry_md, encoding="utf-8")
