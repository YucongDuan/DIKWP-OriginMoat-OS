from __future__ import annotations

import argparse
import json
from pathlib import Path

from .evaluator import evaluate, load_manifest
from .reports import generate_outputs
from .static_audit import write_audit


def analyze_cmd(args: argparse.Namespace) -> None:
    raw = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    manifest = load_manifest(raw)
    report = evaluate(manifest)
    generate_outputs(manifest, report, Path(args.out))
    print(json.dumps({
        "ecosystem": report.ecosystem_name,
        "portfolio_score": report.portfolio_score,
        "copycat_pressure": report.copycat_pressure,
        "recommended_strategy": report.recommended_strategy,
        "output_dir": args.out,
    }, ensure_ascii=False, indent=2))


def static_audit_cmd(args: argparse.Namespace) -> None:
    result = write_audit(Path(args.src), Path(args.out))
    print(json.dumps(result, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="originmoat", description="DIKWP OriginMoat OS CLI")
    sub = parser.add_subparsers(dest="command", required=True)
    a = sub.add_parser("analyze", help="Analyze ecosystem manifest and generate strategic moat outputs")
    a.add_argument("manifest", help="Path to ecosystem manifest JSON")
    a.add_argument("--policy", default=None, help="Optional policy file; reserved for future use")
    a.add_argument("--out", default="outputs/demo", help="Output directory")
    a.set_defaults(func=analyze_cmd)
    s = sub.add_parser("static-audit", help="Run offline static boundary audit")
    s.add_argument("src", help="Source directory")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    s.set_defaults(func=static_audit_cmd)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
