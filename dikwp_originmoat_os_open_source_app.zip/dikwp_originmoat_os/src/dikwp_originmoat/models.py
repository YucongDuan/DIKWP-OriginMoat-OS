from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ProjectAsset:
    name: str
    category: str
    description: str = ""
    public_value: float = 0.5
    copycat_risk: float = 0.5
    attribution_strength: float = 0.5
    official_dependency: float = 0.5
    commercial_potential: float = 0.5
    contains_core_protocol: bool = False
    contains_certification_logic: bool = False
    contains_registry_logic: bool = False
    recommended_license: str = "Apache-2.0"
    notes: List[str] = field(default_factory=list)


@dataclass
class EcosystemManifest:
    ecosystem_name: str
    origin_holder: str
    projects: List[ProjectAsset]
    strategic_intent: str = "preserve origin, grow adoption, capture official certification and service value"


@dataclass
class LayerDecision:
    asset_name: str
    release_layer: str
    reason: str
    attribution_required: bool = True
    official_service_route: str = ""
    copycat_countermeasure: str = ""


@dataclass
class StrategyReport:
    ecosystem_name: str
    origin_holder: str
    portfolio_score: float
    copycat_pressure: float
    attribution_integrity: float
    commercial_route_strength: float
    recommended_strategy: str
    layer_decisions: List[LayerDecision]
    kill_conditions: List[str]
    recovery_actions: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
