# Landing Page Copy

## DIKWP OriginMoat OS

Open source without losing origin.

DIKWP OriginMoat OS helps creators publish DIKWP projects on GitHub while preserving attribution, registry authority, certification value, partner routes and commercial opportunity.

Code can be copied. Origin can be proven. Certification can be controlled. Ecosystems can be built.
