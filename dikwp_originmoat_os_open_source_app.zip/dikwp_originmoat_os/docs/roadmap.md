# Roadmap

## v0.1
Offline manifest analyzer and strategy outputs.

## v0.2
TrustPassport integration and origin capsule validator.

## v0.3
Registry site generator and signed badge verifier.

## v0.4
Partner portal templates and certification workflow.

## v0.5
GitHub Actions integration for release metadata and attribution checks.

## v1.0
Official DIKWP ecosystem registry toolkit.
