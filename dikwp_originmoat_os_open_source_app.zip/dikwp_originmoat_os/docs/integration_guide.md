# Integration Guide

OriginMoat OS can integrate with:

- DIKWP TrustPassport OS for project certification and badge readiness.
- DIKWP ProofLedger OS for claim-to-evidence validation.
- DIKWP IntentGuard OS for agent execution boundary.
- DIKWP AgentTrace OS for runtime audit.
- DIKWP AICAP-Gateway OS for industry protocol governance.

Recommended flow:
1. Run OriginMoat on the portfolio.
2. Publish low-risk adoption drivers.
3. Run TrustPassport on each released project.
4. Keep official issuer and registry controlled.
5. Convert serious adopters into partners.
