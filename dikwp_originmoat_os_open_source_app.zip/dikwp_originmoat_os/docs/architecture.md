# Architecture

DIKWP OriginMoat OS has four layers.

1. Input layer: ecosystem manifest, project asset list, copycat risk, official dependency, attribution strength and commercial potential.
2. Evaluation layer: portfolio score, copycat pressure, attribution integrity, commercial route strength.
3. Release strategy layer: fully open adoption driver, community open with attribution guard, spec open implementation selective, reference core open premium adapters controlled, open verifier private issuer.
4. Output layer: release map, license matrix, controlled asset template, public registry entries, partner blueprint and copycat response pack.

The system is intentionally offline. It does not scrape, enforce, send notices, connect to GitHub, or perform legal actions. It generates strategy artifacts for human review.
