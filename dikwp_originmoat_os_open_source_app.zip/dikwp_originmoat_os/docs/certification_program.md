# DIKWP Certification Program Draft

## Candidate levels
- OM-L0: not registry-ready
- OM-L1: attributed community project
- OM-L2: registry candidate
- OM-L3: verified DIKWP project
- OM-L4: certified DIKWP implementation
- OM-L5: strategic ecosystem partner

## Minimum requirements
- NOTICE and CITATION.cff preserved
- public origin capsule
- evidence ledger for claims
- governance boundary
- conformance tests if protocol-related
- no false official claims

## Controlled assets
- final certification decision
- official badge signing
- registry listing
- revocation status
