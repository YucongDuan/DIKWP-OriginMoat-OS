# Strategic Moat Design

The system uses a layered moat strategy.

## Layer 1: Attribution moat
Every project should preserve NOTICE, CITATION.cff, origin metadata, release chronology and DIKWP naming boundaries.

## Layer 2: Registry moat
Official status should depend on a registry entry controlled by the origin holder or authorized DIKWP organization.

## Layer 3: Certification moat
Open code can be copied, but official conformance certification requires review, test evidence and signed badge issuance.

## Layer 4: Partner moat
Serious users should be converted into registered partners, certified integrators, training participants or enterprise support clients.

## Layer 5: Adapter moat
Reference cores can be open. Industry-specific templates, procurement playbooks, certification reviews and client deployment support can remain commercial.

## Layer 6: Chronology moat
Early GitHub releases, CITATION files, DOI-style release metadata and origin capsules form a public evidence trail.
