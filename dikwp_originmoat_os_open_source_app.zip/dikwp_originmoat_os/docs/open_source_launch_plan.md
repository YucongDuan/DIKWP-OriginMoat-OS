# Open Source Launch Plan

1. Publish a clean GitHub repository with README, LICENSE, NOTICE and CITATION.cff.
2. Pin OriginMoat OS and TrustPassport OS as the strategic foundation projects.
3. Publish a blog post: Why DIKWP open source needs origin, registry and certification moats.
4. Release demo outputs showing high-copycat-risk project classification.
5. Publish the official registry playbook.
6. Invite community projects to generate their TrustPassport candidate entries.
7. Open a partner application form.
8. Publish quarterly registry snapshots.
9. Start paid certification and training after public credibility is established.
