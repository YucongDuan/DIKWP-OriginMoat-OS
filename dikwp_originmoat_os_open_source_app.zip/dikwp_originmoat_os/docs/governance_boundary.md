# Governance Boundary

Allowed uses:
- strategic release planning
- attribution analysis
- open-core strategy
- certification route planning
- partner program planning
- copycat risk assessment

Blocked uses:
- automated legal threats
- deceptive certification claims
- hidden telemetry
- doxxing or harassment of derivatives
- malicious license traps
- false official registry claims

Formal legal actions require qualified legal review.
