# GitHub Release Draft

## DIKWP OriginMoat OS v0.1.0

This first release provides an offline strategy engine for DIKWP project release planning, attribution integrity and ecosystem value capture.

Highlights:
- Portfolio-level copycat pressure scoring
- Open-core release layer recommendations
- Controlled official asset registry template
- License and attribution matrix
- Public registry candidate entries
- Copycat response pack
- Partner program blueprint

Boundary: this tool does not provide legal advice or automated enforcement.
